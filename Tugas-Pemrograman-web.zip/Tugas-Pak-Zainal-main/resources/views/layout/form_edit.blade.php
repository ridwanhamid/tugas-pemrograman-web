@extends('layout.master')
@section('content')
<div class="card">
    <div class="card-body p-3">
    @yield('conten')
    </div>
</div>
@endsection