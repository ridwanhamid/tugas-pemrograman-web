<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="{{url('form_user')}}">
          <i class="bi bi-incognito"></i>
          <span>User</span>
        </a>
      </li>
      <!-- End User Nav -->
      
      <li class="nav-item">
        <a class="nav-link " href="{{url('form_barang')}}">
          <i class="bi bi-cart4"></i>
          <span>Barang</span>
        </a>
      </li>
      <!-- End Barang Nav -->

      <li class="nav-item">
        <a class="nav-link " href="{{url('form_member')}}">
          <i class="bi bi-pin-angle-fill"></i>
          <span>Members</span>
        </a>
      </li>
      <!-- End Member Nav -->

    </ul>

</aside>
<!-- End Sidebar-->